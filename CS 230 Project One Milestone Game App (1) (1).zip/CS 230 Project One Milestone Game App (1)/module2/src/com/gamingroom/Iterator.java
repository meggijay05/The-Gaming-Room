package com.gamingroom;

public class Iterator<T> {

}
